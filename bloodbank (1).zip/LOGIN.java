package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class LOGIN extends JFrame {

	private JPanel contentPane;
	private JTextField fname;
	private JTextField username;
	private JTextField dateofbirth;
	private JTextField gender;
	private JTextField bloodgroup;
	private JTextField mob;
	private JTextField address;
	private JTextField emailaddress;
	private JTextField password;
	private JTextField confirmpassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LOGIN frame = new LOGIN();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LOGIN() {
		setTitle("Signup");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 464, 547);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JLabel name = new JLabel("Name");
		name.setBounds(90, 112, 46, 14);
		contentPane.add(name);
		
		JLabel UserName = new JLabel("UserName");
		UserName.setBounds(90, 137, 78, 14);
		contentPane.add(UserName);
		
		JLabel Dob = new JLabel("Date Of Birth");
		Dob.setBounds(90, 165, 106, 14);
		contentPane.add(Dob);
		
		JLabel Gender = new JLabel("Gender");
		Gender.setBounds(90, 190, 46, 14);
		contentPane.add(Gender);
		
		JLabel Bloodgroup = new JLabel("Blood Group");
		Bloodgroup.setBounds(90, 215, 78, 14);
		contentPane.add(Bloodgroup);
		
		JLabel MOB = new JLabel("Mobile No");
		MOB.setBounds(90, 240, 106, 14);
		contentPane.add(MOB);
		
		JLabel ADDRess = new JLabel("Address");
		ADDRess.setBounds(90, 265, 106, 14);
		contentPane.add(ADDRess);
		
		JLabel Email = new JLabel("Email");
		Email.setBounds(90, 291, 106, 14);
		contentPane.add(Email);
		
		JLabel Password = new JLabel("Password");
		Password.setBounds(90, 316, 89, 14);
		contentPane.add(Password);
		
		JLabel confirmPass = new JLabel("Confirm Password");
		confirmPass.setBounds(90, 341, 106, 14);
		contentPane.add(confirmPass);
		
		JButton Signup = new JButton("SIGNUP");
		Signup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SignIn si = new SignIn();
				si.setVisible(true);
				dispose();
				
				String name=fname.getText();
					String user_name=username.getText();
					String dob=dateofbirth.getText();
					String Gender=gender.getText();
					String blood=bloodgroup.getText();
					String mobile=mob.getText();
				        String adress=address.getText();
				        String email=emailaddress.getText();
				        String Password=password.getText();
				        String confirmpass=confirmpassword.getText();
					try {
						Connection c=null;
						Class.forName("org.postgresql.Driver");
						c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/project","postgres","lasvegas");
						String query="INSERT INTO createacc values('"+name+"','"+user_name+"','"+dob+"','"+Gender+"','"+blood+"','"+mobile+"','"+adress+"','"+email+"','"+Password+"','"+confirmpass+"')";
						Statement sta=c.createStatement();
						int x= sta.executeUpdate(query);
						if(x==0) {
							JOptionPane.showMessageDialog(Signup,"user already have an account");
						}else {
							JOptionPane.showMessageDialog(Signup,"Sucessfully registered");
						}
						c.close();
					}
					catch(Exception e1){
						e1.printStackTrace();
					}	
			}
		});
		Signup.setBounds(155, 413, 96, 31);
		contentPane.add(Signup);
		
		fname = new JTextField();
		fname.setBounds(206, 109, 86, 20);
		contentPane.add(fname);
		fname.setColumns(10);
		
		username = new JTextField();
		username.setBounds(206, 134, 86, 20);
		contentPane.add(username);
		username.setColumns(10);
		
		dateofbirth = new JTextField();
		dateofbirth.setBounds(206, 162, 86, 20);
		contentPane.add(dateofbirth);
		dateofbirth.setColumns(10);
		
		gender = new JTextField();
		gender.setBounds(206, 187, 86, 20);
		contentPane.add(gender);
		gender.setColumns(10);
		
		bloodgroup = new JTextField();
		bloodgroup.setBounds(206, 212, 86, 20);
		contentPane.add(bloodgroup);
		bloodgroup.setColumns(10);
		
		mob = new JTextField();
		mob.setBounds(206, 237, 86, 20);
		contentPane.add(mob);
		mob.setColumns(10);
		
		address = new JTextField();
		address.setBounds(206, 262, 86, 20);
		contentPane.add(address);
		address.setColumns(10);
		
		emailaddress = new JTextField();
		emailaddress.setBounds(206, 288, 86, 20);
		contentPane.add(emailaddress);
		emailaddress.setColumns(10);
		
		JLabel title = new JLabel("Create Account");
		title.setFont(new Font("Times New Roman", Font.BOLD, 24));
		title.setBounds(145, 25, 175, 44);
		contentPane.add(title);
		
		password = new JTextField();
		password.setBounds(206, 313, 86, 20);
		contentPane.add(password);
		password.setColumns(10);
		
		confirmpassword = new JTextField();
		confirmpassword.setBounds(206, 338, 86, 20);
		contentPane.add(confirmpassword);
		confirmpassword.setColumns(10);
	}
}
