package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Canvas;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SignIn extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignIn frame = new SignIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignIn() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 474, 364);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Username = new JLabel("Username");
		Username.setBounds(96, 107, 106, 14);
		contentPane.add(Username);
		
		JLabel password = new JLabel("Password");
		password.setBounds(96, 143, 83, 14);
		contentPane.add(password);
		
		textField = new JTextField();
		textField.setBounds(250, 104, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(250, 140, 86, 20);
		contentPane.add(passwordField);
		
		JButton signinb = new JButton("SIGNIN");
		signinb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BB t = new BB();
				t.setVisible(true);
				dispose();
			}
		});
		signinb.setBounds(164, 203, 89, 23);
		contentPane.add(signinb);
		
		JLabel forgotpass = new JLabel("Do not have an account:");
		forgotpass.setBounds(96, 242, 164, 14);
		contentPane.add(forgotpass);
		
		JButton signupb = new JButton("SIGNUP");
		signupb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LOGIN log = new LOGIN();
				log.setVisible(true);
				dispose();
			}
		});
		signupb.setBounds(230, 238, 89, 23);
		contentPane.add(signupb);
		
		JLabel signin = DefaultComponentFactory.getInstance().createTitle("SIGN IN");
		signin.setFont(new Font("Times New Roman", Font.BOLD, 30));
		signin.setBounds(150, 11, 136, 58);
		contentPane.add(signin);
	}
}
