package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class donation extends JFrame {

	private JPanel contentPane;
	private JTextField dd;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					donation frame = new donation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public donation() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 608, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel donation = DefaultComponentFactory.getInstance().createTitle("DONATION");
		donation.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		donation.setBounds(209, 49, 179, 64);
		contentPane.add(donation);
		
		JLabel bg = new JLabel("Blood Group");
		bg.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		bg.setBounds(117, 160, 108, 20);
		contentPane.add(bg);
		
		JComboBox bloodgroup = new JComboBox();
		bloodgroup.setEditable(true);
		bloodgroup.setModel(new DefaultComboBoxModel(new String[] {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"}));
		bloodgroup.setForeground(new Color(0, 0, 0));
		bloodgroup.setToolTipText("");
		bloodgroup.setBounds(251, 158, 86, 22);
		contentPane.add(bloodgroup);
		
		JLabel bags = new JLabel("No. of Bags");
		bags.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		bags.setBounds(117, 198, 128, 22);
		contentPane.add(bags);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(251, 201, 86, 20);
		contentPane.add(spinner);
		
		JTextArea bag = new JTextArea();
		bag.setBackground(SystemColor.control);
		bag.setFont(new Font("Monospaced", Font.PLAIN, 11));
		bag.setText("*One bag contains 0.5 liters of blood");
		bag.setBounds(251, 225, 305, 20);
		contentPane.add(bag);
		
		JLabel ddate = new JLabel("Donation Date");
		ddate.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		ddate.setBounds(117, 284, 128, 20);
		contentPane.add(ddate);
		
		JLabel place = new JLabel("Place");
		place.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		place.setBounds(117, 327, 101, 20);
		contentPane.add(place);
		
		dd = new JTextField();
		dd.setBounds(251, 283, 86, 20);
		contentPane.add(dd);
		dd.setColumns(10);
		
		textField = new JTextField();
		textField.setBounds(251, 329, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton confirm = new JButton("CONFIRM");
		confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				confirmation cn = new confirmation();
				cn.setVisible(true);
				dispose();
			}
		});
		confirm.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		confirm.setBounds(336, 424, 138, 39);
		contentPane.add(confirm);
		
		JButton save = new JButton("SAVE");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String BG=bg.getText();
				String Bags=bags.getText();
				String Ddate=ddate.getText();
				String Place=place.getText();
				
				try {
					Connection c=null;
					Class.forName("org.postgresql.Driver");
					c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/project","postgres","lasvegas");
					String query="INSERT INTO donation values('"+BG+"','"+Bags+"','"+Ddate+"','"+Place+"')";
					Statement sta=c.createStatement();
					int x= sta.executeUpdate(query);
					if(x==0) {
						JOptionPane.showMessageDialog(save,"This is already exist");
					}else {
						JOptionPane.showMessageDialog(save,"Sucessfully registered");
					}
					c.close();
				}
				catch(Exception e1){
					e1.printStackTrace();
				}	

			}
		});
		save.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		save.setBounds(117, 424, 138, 39);
		contentPane.add(save);
	}
}
