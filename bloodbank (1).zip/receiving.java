package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.awt.event.ActionEvent;
import java.sql.Statement;
import java.sql.DriverManager;

public class receiving extends JFrame {

	private JPanel ddate;
	private JTextField textField;
	private JTextField placee;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					receiving frame = new receiving();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public receiving() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 581, 569);
		ddate = new JPanel();
		ddate.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(ddate);
		ddate.setLayout(null);
		
		JLabel receiving = DefaultComponentFactory.getInstance().createTitle("RECEIVING");
		receiving.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		receiving.setBounds(190, 37, 182, 60);
		ddate.add(receiving);
		
		JLabel bg = new JLabel("Blood Group");
		bg.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		bg.setBounds(107, 165, 149, 29);
		ddate.add(bg);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"}));
		comboBox.setEditable(true);
		comboBox.setBounds(285, 170, 116, 22);
		ddate.add(comboBox);
		
		JLabel bags = new JLabel("No. of Bags");
		bags.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		bags.setBounds(107, 217, 132, 22);
		ddate.add(bags);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(285, 220, 116, 20);
		ddate.add(spinner);
		
		JLabel date = new JLabel("Date");
		date.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		date.setBounds(107, 281, 132, 22);
		ddate.add(date);
		
		textField = new JTextField();
		textField.setBounds(285, 281, 116, 20);
		ddate.add(textField);
		textField.setColumns(10);
		
		JLabel place = new JLabel("Place");
		place.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		place.setBounds(107, 338, 132, 22);
		ddate.add(place);
		
		placee = new JTextField();
		placee.setBounds(285, 341, 116, 20);
		ddate.add(placee);
		placee.setColumns(10);
		
		JButton save = new JButton("SAVE");
		save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String bloodgroup=bg.getText();
				String number_of_bags=bags.getText();
				String dateofreceiving=date.getText();
				String branch= place.getText();
				try {
					Connection c=null;
					Class.forName("org.postgresql.Driver");
					c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/project","postgres","lasvegas");
					String query="INSERT INTO receiving values('"+bloodgroup+"','"+number_of_bags+"','"+dateofreceiving+"','"+branch+"')";
					Statement sta=c.createStatement();
					int x= sta.executeUpdate(query);
					if(x==0) {
						JOptionPane.showMessageDialog(save,"This is already exist");
					}else {
						JOptionPane.showMessageDialog(save,"Sucessfully added");
					}
					c.close();
				}
				catch(Exception e1){
					e1.printStackTrace();
				}
			}
		});
		save.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		save.setBounds(82, 447, 132, 44);
		ddate.add(save);
		
		JButton confirm = new JButton("CONFIRM");
		confirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				confirmation cn = new confirmation();
				cn.setVisible(true);
				dispose();
			}
		});
		confirm.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		confirm.setBounds(340, 448, 154, 42);
		ddate.add(confirm);
	}
}
